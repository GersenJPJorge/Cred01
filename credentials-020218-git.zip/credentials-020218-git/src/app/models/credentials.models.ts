export class Credentials {

  constructor(
      public id: number,
      public scope: string,
      public authorities: string,
      public acessTokenValidity: number,
      public refreshTokenValidity: number,
      public authorizedGrantType: string,
      public clientSecret: string,
      public clientId: string,
  ) {}
}

//  "returnCode": "0",
//  "listCredentials":
