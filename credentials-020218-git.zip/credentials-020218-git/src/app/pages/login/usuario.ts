export class Usuario {
  userLogin: string;
  userPass: string;
}
