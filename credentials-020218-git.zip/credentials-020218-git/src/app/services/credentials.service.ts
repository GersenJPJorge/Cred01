import { Http, Headers, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { Credentials } from './../models/credentials.models';

@Injectable()
export class CredentialsService{

   private credentialsUrl = 'https://172.18.195.10:5601/v1/credentials';

   private headers: Headers = new Headers ({'Content-Type' : 'application/json'})


    constructor(
       private http: Http
    ) {}

    getCredentials() : Promise<Credentials[]> {

       return this.http.get(this.credentialsUrl)
         .toPromise()
         .then(response => response.json().data as Credentials[])

         .catch(this.trataErro);
        }
      private trataErro(err : any) : Promise<any> {
        console.log('Erro : ' , err );
          return Promise.reject(err.message || err );
        }

    getCredential(id:number): Promise<Credentials> {
      console.log('----------> getCredential')
           return this.getCredentials()
           .then((credentials: Credentials[]) => credentials.find(credential => credential.id === id));
          }

   create(credential: Credentials): Promise<Credentials> {
    console.log('----------> create')
        return this.http.post(this.credentialsUrl, JSON.stringify(credential), {headers:this.headers})
        .toPromise()
        .then((response : Response) => {
            console.log(response.json().data);
            return response.json().data as Credentials;
        })
        .catch(this.trataErro);
    }
    update(credential: Credentials): Promise<Credentials> {
      console.log('----------> update')
      const url = `${this.credentialsUrl}/${credential.id}`; //app/credential/:id
      return this.http
      .put(url, JSON.stringify(credential), {headers:this.headers})
      .toPromise()
      .then(() => credential as Credentials)
      .catch(this.trataErro);
  }
  delete(credential: Credentials): Promise<Credentials> {
    console.log('----------> delete')
    const url = `${this.credentialsUrl}/${credential.id}`; //app/credential/:id
    return this.http
    .delete(url, {headers:this.headers})
    .toPromise()
    .then(() => credential as Credentials)
    .catch(this.trataErro);
}
}

console.log('----------> credentials.service')
