import { HttpModule } from '@angular/http';
// import { CredentialsModel } from './credentials.model';
import { NgModule } from '@angular/core';
import { NgModel, FormsModule } from '@angular/forms';
import { AppComponent } from './../app.component';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule, Title } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { CredentialsComponent } from './credentials.component';
import { CredentialsService } from './../services/credentials.service';
import { CredentialsInclusaoComponent } from './credentials-inclusao/credentials-inclusao.component';
import { CredentialsRoutingModule } from './../credentials/credentials-router';

@NgModule({
  declarations: [
    CredentialsComponent,
    CredentialsInclusaoComponent
],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    AngularFontAwesomeModule,
    CredentialsRoutingModule,
    HttpModule,
    HttpClientModule
  ],
  providers: [
    Title,
    CredentialsService,
  ],
  bootstrap: []
})
export class CredentialsModule { }
