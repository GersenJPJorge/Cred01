import { Component, OnInit } from '@angular/core';
import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Usuario } from './../pages/login/usuario';
import { TokenService } from './../services/token.service';
import { CredentialsService } from './../services/credentials.service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-credentials',
  templateUrl: './credentials.component.html',
  styleUrls: ['./credentials.component.css'],
  providers: [Usuario]
})

@Injectable()
export class CredentialsComponent implements OnInit {

  constructor(private usuario: Usuario, public token: TokenService, private http: HttpClient, public credentials: CredentialsService) { }

  ngOnInit() {

    console.log('----------> CredentialsComponent usertoken', this.token.userToken);

    const urlGetCompany = 'https://172.18.195.10:5601/v1/credentials';
    let headersParam = new HttpHeaders();
    headersParam = headersParam.set('Content-Type', 'application/json');
    headersParam = headersParam.set('Authorization', 'Bearer ' + this.token.userToken);
    headersParam = headersParam.set('environmentName', 'hml');
    headersParam = headersParam.set('systemName', 'cadu');
    headersParam = headersParam.set('productName', 'webCadu');
    headersParam = headersParam.set('companyName', 'cadu');

    console.log('---------->  CredentialsComponent GET acesso headers param', headersParam);
    this.http.get(urlGetCompany, {
        headers: headersParam
          })

    .subscribe(
      data => {
          this.credentials = data['listCredentials'];
        console.log('----------> CredentialsComponent acesso credential', data);
      },

      error => {
        console.log('Erro. Se persistir, entre em contato com o suporte técnico.', error);
      }
    );
  }

  // Função para inserir uma credential
  incluiCredential() {
    console.log('----------> incluiCredential');
  }

  // Função para editar uma credential
  editaCredential() {
    console.log('----------> editaCredential');
  }

  // Função para excluir uma credential
  excluiCredential() {
    console.log('----------> excluiCredential');
  }

}
