import { CredentialsInclusaoComponent } from './../credentials/credentials-inclusao/credentials-inclusao.component';
import { RouterModule, Routes} from '@angular/router';
import { AuthGuard } from './../guards/auth-guard';
import { CredentialsComponent } from './credentials.component';

const CredentialsRoutes: Routes = [
   {
    path: 'inclusao',
    component: CredentialsInclusaoComponent,
    canActivate: [AuthGuard],
//    data: {title: 'Credentials Inclusão'}
    },
//  {
//    path: '',
//    component: CredentialsComponent,
//    canActivate: [AuthGuard],
//    data: {title: 'Credentials'}
// },
// {
//  path: 'credentials',
//  component: CredentialsComponent,
//  canActivate: [AuthGuard],
//  data: {title: 'Credentials'}
// },
];

export const CredentialsRoutingModule = RouterModule.forChild(CredentialsRoutes);
