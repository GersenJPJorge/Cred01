import { Component, OnInit } from '@angular/core';
import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

// import { Usuario } from './../pages/login/usuario';
import { TokenService } from './../../services/token.service';
import { CredentialsService } from './../../services/credentials.service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-credentials-inclusao',
  templateUrl: './credentials-inclusao.component.html',
  styleUrls: ['./credentials-inclusao.component.css']
})

@Injectable()
export class CredentialsInclusaoComponent implements OnInit {

//  constructor(private usuario: Usuario, public token: TokenService, private http: HttpClient, public credentials: CredentialsService) { }
  constructor(public token: TokenService, private http: HttpClient, public credentials: CredentialsService) { }

  ngOnInit() {

    console.log('----------> CredentialsInclusaoComponent usertoken', this.token.userToken)

    const urlGetCompany ='https://172.18.195.10:5601/v1/credential';
    let headersParam = new HttpHeaders();
    headersParam = headersParam.set('Content-Type', 'application/json');
    headersParam = headersParam.set('Authorization', 'Bearer ' + this.token.userToken);
    headersParam = headersParam.set('environmentName', 'hml');
    headersParam = headersParam.set('systemName', 'cadu');
    headersParam = headersParam.set('productName', 'webCadu');
    headersParam = headersParam.set('companyName', 'cadu');

    console.log('----------> CredentialsInclusaoComponent POST acesso headers param', headersParam);
    this.http.post(urlGetCompany, {
        headers: headersParam
          })
    .subscribe(
      data => {
          this.credentials = data['listCredentials'];
        console.log('----------> CredentialsInclusaoComponent acesso credential', data);
      },
      error => {
        console.log('Erro. Se persistir, entre em contato com o suporte técnico.', error);
      }
    );
  }
}
